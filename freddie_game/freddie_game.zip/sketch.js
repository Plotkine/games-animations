fps=60;
screenSize=750;

lateralSpeed=140
jumpVelocity=3;

freddieBallSize=50;
freddieBallSpeed=3;
freddieBallDelay=285;

bieberCryingDelay=285;

imgSize=125;

shootAnimationTime=0.3*fps;

//don't change those variables
lateralSpeed=lateralSpeed/fps;
jumpVelocity=450*jumpVelocity/fps;
gravity=jumpVelocity*2.5/fps;
oldTimeFireball=new Date().getTime() - freddieBallDelay;
oldTimeBieberCrying=new Date().getTime() - bieberCryingDelay;
welComeScreen="yes";

function preload() {
  soundFormats('mp3', 'ogg');
  mySoundIntro = loadSound('under_pressure.mp3');
  mySoundGame = loadSound('fat_bottom_girls.mp3');
  mySoundFireball = loadSound('explosion_2.mp3');
}

class ball {
  constructor(date,img,imgRatio,x,y,speed) {
    this.date=date; //moment of creation
    this.x=x;
    this.y=y;
    this.speed=speed;
    this.img=img;
    this.imgRatio=imgRatio
    this.imgHeight=freddieBallSize*imgRatio;
  }
  draw() {
    image(this.img,this.x,this.y,freddieBallSize,this.imgHeight);
  }
  updatePos() {
    this.x += freddieBallSpeed;
  }
}

class bieber {
  constructor(img,imgRatio) {
    this.x=screenSize - 10;
    this.y=-10;
    this.img=img;
    this.imgRatio=imgRatio
    this.imgHeight=imgSize*imgRatio;
  }
  draw() {
    //drawing bieber
    image(this.img,this.x - imgSize,screenSize/5*4 - this.imgHeight + this.y,imgSize,this.imgHeight);
  }
}

class freddie {
  constructor(img,imgRatio,ennemy) {
    this.x=10;
    this.y=0;
    this.inJump="no";
    this.velocity=jumpVelocity; //for vertical jumps
    this.img=img;
    this.imgRatio=imgRatio
    this.imgHeight=imgSize*imgRatio;
    this.balls=[];
    this.ennemy=ennemy;
  }
  move(direction) {
    if (direction === "right") {
      this.x+=lateralSpeed;
    }
    else if (direction === "up") {
      this.inJump="up";
    }
    else if (direction === "left") {
      this.x-=lateralSpeed;
    }
    }
  constrain() {
    if (this.x < 0) { //left of screen
      this.x=0;
    }
    else if (this.x > screenSize - imgSize) { //right of screen
      this.x=screenSize - imgSize;
    }
    else if (this.x + imgSize + freddieBallSize > this.ennemy.x - imgSize) { //right of screen
      this.x=this.ennemy.x - 2*imgSize - freddieBallSize;
    }
    //if (this.y > 0) { we dont do it here cause it is condition of jump ending
  }
  draw() {
    //replacing freddie
    this.constrain();
    
    //drawing freddie
    image(this.img,this.x,screenSize/5*4 - this.imgHeight + this.y,imgSize,this.imgHeight);
    
    //drawing balls
    fill(255,50,50);
    for (let i=0; i < this.balls.length; i++) {
      this.balls[i].draw();
      this.balls[i].updatePos();
      //clean balls out of screen
      if (this.balls[i].x > screenSize) {
        this.balls.splice(i,1); //delete the ball
      }
    }
    
    //jump position update
    if (this.inJump !== "no") {  //in a jump
      if (this.y > 0) { //end of jump
        this.y=0;
        this.velocity=jumpVelocity;
        this.img=imgStatic;
        this.imgRatio=imgStaticRatio;
        this.inJump="no";
      }
      else { //still in jump
        if (this.velocity < 0){ //we start going down
          this.velocity=0;
          this.inJump="down";
        }
        else if (this.inJump === "up") {
          this.velocity-=gravity;
          this.y-=this.velocity;
        }
        else if (this.inJump ==="down") {
          this.velocity+=gravity;
          this.y+=this.velocity;
        }
      }
    }
  }
}

function setup() {
  mySoundIntro.play();
  createCanvas(screenSize, screenSize);
  frameRate(fps);
  imgWelcome=loadImage('welcome_image.png');
  imgJump=loadImage('jump.png'); //493x736
  imgJumpRatio=736/493;
  imgStatic=loadImage('static.png'); //241x377
  imgStaticRatio=377/241;
  imgShoot=loadImage('shoot.png'); //350x631
  imgShootRatio=631/350
  imgFireball=loadImage('fireball.png'); //322x261
  imgFireballRatio=261/322
  imgBieber=loadImage('bieber.png'); //213x331
  imgBieberRatio=331/213
  imgBieberCry=loadImage('bieber_cry.png'); //213x331
  imgBieberCryRatio=331/213
  /*imgCloud=loadImage('cloud.png'); //350x140
  imgCloudRatio=140/350;*/
  aBieber=new bieber(imgBieber,imgBieberRatio);
  aFreddie=new freddie(imgStatic,imgStaticRatio,aBieber);
}

function draw() {
  if (welComeScreen === "yes") {
    image(imgWelcome,0,0,750,750);
    if (keyIsDown(32)) { //spacebar
      welComeScreen="no";
      mySoundIntro.stop();
      mySoundGame.play();
    }
  }
  else {
    //bieber crying
    for (let i=0; i < aFreddie.balls.length; i++) {
      if ((aFreddie.balls[i].x > aBieber.x - imgSize) && (aFreddie.balls[i].y - (screenSize/5*4 - aFreddie.imgHeight + aFreddie.y) >= aBieber.y)) {
        aBieber.img=imgBieberCry;
        aBieber.imgRatio=imgBieberCryRatio;
        aBieber.imgHeight=imgSize*aBieber.imgRatio;
        aFreddie.balls.splice(i,1); //delete the ball
        oldTimeBieberCrying=new Date().getTime();
      }
    }
    newTime=new Date().getTime();
    if (newTime > oldTimeBieberCrying + bieberCryingDelay) {
        aBieber.img=imgBieber;
        aBieber.imgRatio=imgBieberRatio;
        aBieber.imgHeight=imgSize*aBieber.imgRatio;
    }
    background(220);
    textSize(25);
    fill(50,50,255);
    text('LEVEL 1',10,35);
    textSize(15);
    fill(50,50,50);
    text('<Esc> main menu',10,60);
    line(0,screenSize/5*4,screenSize,screenSize/5*4)
    aFreddie.draw();
    aBieber.draw();
    if (keyIsDown(RIGHT_ARROW)) {
      aFreddie.move("right");
    }  
    if (keyIsDown(UP_ARROW) && (aFreddie.inJump === "no")) {
      aFreddie.img=imgJump;
      aFreddie.imgRatio=imgJumpRatio;
      aFreddie.move("up");
    }
    if (keyIsDown(LEFT_ARROW)) {
      aFreddie.move("left");
    }
    if (keyIsDown(32)) { //spacebar
      newTime=new Date().getTime();
      if (newTime > oldTimeFireball + freddieBallDelay) {
        mySoundFireball.play();
        aFreddie.balls.push(new ball(new Date().getTime(),imgFireball,imgFireballRatio,aFreddie.x + imgSize + 10,screenSize/5*4 - aFreddie.imgHeight + aFreddie.y + 10,freddieBallSpeed));
        /*image(imgCloud,aFreddie.x + imgSize + 10,screenSize/5*4 - aFreddie.imgHeight + aFreddie.y + 10,freddieBallSize,freddieBallSize*imgCloudRatio);*/ //cloud
        aFreddie.img=imgShoot;
        aFreddie.imgRatio=imgShootRatio;
        aFreddie.shootTime=shootAnimationTime+1;
        oldTimeFireball=newTime;
      }
    }
    if (keyIsDown(27)) { //escape
      welComeScreen = "yes";
      mySoundGame.stop();
      mySoundIntro.play();
    }
    if (aFreddie.shootTime > 0) {
    aFreddie.shootTime-=1;
    }
    else if (aFreddie.img === imgShoot && aFreddie.shootTime === 0) {
      if (aFreddie.y === 0) { //au sol
        aFreddie.img=imgStatic;
        aFreddie.imgRatio=imgStaticRatio;
      }
      else {//jumping
        aFreddie.img=imgJump;
        aFreddie.imgRatio=imgJumpRatio; 
      }
    }
  }
}